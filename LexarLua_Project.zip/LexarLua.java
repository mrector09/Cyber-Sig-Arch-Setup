
// LexarLua - Advanced JavaFX GUI (Java)
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LexarLua extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("LexarLua - Advanced Lua Executor");
        BorderPane layout = new BorderPane();

        // Sidebar
        VBox sidebar = new VBox();
        Button attachButton = new Button("Attach to Roblox");
        Button scriptHubButton = new Button("Script Hub");
        Button settingsButton = new Button("Settings");
        sidebar.getChildren().addAll(attachButton, scriptHubButton, settingsButton);
        layout.setLeft(sidebar);

        // Main Panel (Dynamic Content)
        TextArea scriptArea = new TextArea("Enter your script here...");
        Button executeButton = new Button("Execute Script");
        VBox mainPanel = new VBox(scriptArea, executeButton);
        layout.setCenter(mainPanel);

        executeButton.setOnAction(e -> {
            String script = scriptArea.getText();
            System.out.println("Executing Script: " + script);
        });

        Scene scene = new Scene(layout, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
