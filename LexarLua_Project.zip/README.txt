
# LexarLua - Advanced JavaFX Lua Executor

## Features:
- Sleek, modern JavaFX GUI with a sidebar (Attach, Script Hub, Settings).
- Script Hub allows direct input and execution of Lua scripts.
- Manual "Attach to Roblox" functionality.
- Smooth, dark, and immersive UI design.

## How to Use:
1. Compile the Java source file:
   javac LexarLua.java
2. Run the application:
   java LexarLua

## Customization:
- Modify the Java source code to add more features or enhance the GUI.
- The JavaFX interface is clean and can be customized for a premium look.
