
-- Sword Simulator UI Script (HUD, Shop, and Pet Inventory)

-- HUD Setup
local player = game.Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local hud = Instance.new("ScreenGui", playerGui)
hud.Name = "SwordSimulatorHUD"

local strengthDisplay = Instance.new("TextLabel", hud)
strengthDisplay.Position = UDim2.new(0.05, 0, 0.05, 0)
strengthDisplay.Size = UDim2.new(0.2, 0, 0.05, 0)
strengthDisplay.Text = "Strength: 0"
strengthDisplay.TextColor3 = Color3.fromRGB(255, 255, 255)
strengthDisplay.BackgroundTransparency = 1

local coinsDisplay = Instance.new("TextLabel", hud)
coinsDisplay.Position = UDim2.new(0.05, 0, 0.1, 0)
coinsDisplay.Size = UDim2.new(0.2, 0, 0.05, 0)
coinsDisplay.Text = "Coins: 0"
coinsDisplay.TextColor3 = Color3.fromRGB(255, 255, 255)
coinsDisplay.BackgroundTransparency = 1

-- Shop UI
local shopGui = Instance.new("ScreenGui", playerGui)
shopGui.Name = "ShopUI"

local shopFrame = Instance.new("Frame", shopGui)
shopFrame.Position = UDim2.new(0.7, 0, 0.2, 0)
shopFrame.Size = UDim2.new(0.25, 0, 0.5, 0)
shopFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 40)

local shopTitle = Instance.new("TextLabel", shopFrame)
shopTitle.Text = "Shop"
shopTitle.Size = UDim2.new(1, 0, 0.2, 0)
shopTitle.TextColor3 = Color3.fromRGB(255, 255, 255)
shopTitle.BackgroundTransparency = 1

local buySwordButton = Instance.new("TextButton", shopFrame)
buySwordButton.Text = "Buy Sword (10 Coins)"
buySwordButton.Position = UDim2.new(0.1, 0, 0.3, 0)
buySwordButton.Size = UDim2.new(0.8, 0, 0.15, 0)
buySwordButton.BackgroundColor3 = Color3.fromRGB(60, 60, 90)

local buyEggButton = Instance.new("TextButton", shopFrame)
buyEggButton.Text = "Buy Egg (50 Coins)"
buyEggButton.Position = UDim2.new(0.1, 0, 0.5, 0)
buyEggButton.Size = UDim2.new(0.8, 0, 0.15, 0)
buyEggButton.BackgroundColor3 = Color3.fromRGB(60, 60, 90)

-- Pet Inventory UI
local petInventory = Instance.new("ScreenGui", playerGui)
petInventory.Name = "PetInventory"

local inventoryFrame = Instance.new("Frame", petInventory)
inventoryFrame.Position = UDim2.new(0.1, 0, 0.7, 0)
inventoryFrame.Size = UDim2.new(0.3, 0, 0.25, 0)
inventoryFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 40)

local inventoryTitle = Instance.new("TextLabel", inventoryFrame)
inventoryTitle.Text = "Pet Inventory"
inventoryTitle.Size = UDim2.new(1, 0, 0.2, 0)
inventoryTitle.TextColor3 = Color3.fromRGB(255, 255, 255)
inventoryTitle.BackgroundTransparency = 1

local petList = Instance.new("TextLabel", inventoryFrame)
petList.Text = "No Pets Hatched"
petList.Position = UDim2.new(0.05, 0, 0.3, 0)
petList.Size = UDim2.new(0.9, 0, 0.6, 0)
petList.TextColor3 = Color3.fromRGB(255, 255, 255)
petList.BackgroundTransparency = 1

-- UI Interactions (Shop Buttons)
buySwordButton.MouseButton1Click:Connect(function()
    print("Sword Purchased (simulated)")
end)

buyEggButton.MouseButton1Click:Connect(function()
    print("Egg Purchased (simulated)")
end)
