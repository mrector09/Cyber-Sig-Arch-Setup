
-- Sword Simulator Final Script (Integrated UI with Core Mechanics)

-- Variables
local player = game.Players.LocalPlayer
local strength = 0
local coins = 0
local petMultiplier = 1

-- UI Elements
local playerGui = player:WaitForChild("PlayerGui")
local hud = playerGui:WaitForChild("SwordSimulatorHUD")
local strengthDisplay = hud.StrengthDisplay
local coinsDisplay = hud.CoinsDisplay

-- Sword System (Swinging)
local sword = workspace:WaitForChild("TrainingSword")
sword.Activated:Connect(function()
    strength = strength + (1 * petMultiplier) -- Gain strength with pet multiplier
    strengthDisplay.Text = "Strength: " .. math.floor(strength)
end)

-- Selling System (Sell Strength for Coins)
local sellZone = workspace:WaitForChild("SellZone")
sellZone.Touched:Connect(function(hit)
    if hit.Parent:FindFirstChild("Humanoid") then
        coins = coins + strength
        strength = 0
        strengthDisplay.Text = "Strength: " .. strength
        coinsDisplay.Text = "Coins: " .. coins
    end
end)

-- Shop System (Buy Swords)
local shopGui = playerGui:WaitForChild("ShopUI")
local buySwordButton = shopGui.ShopFrame.BuySwordButton
buySwordButton.MouseButton1Click:Connect(function()
    if coins >= 10 then -- Price for the next sword
        coins = coins - 10
        coinsDisplay.Text = "Coins: " .. coins
        sword.Damage.Value = sword.Damage.Value + 1 -- Stronger sword
    end
end)

-- Pet System (Hatch Pets)
local petHatchery = workspace:WaitForChild("PetHatchery")
local buyEggButton = shopGui.ShopFrame.BuyEggButton
buyEggButton.MouseButton1Click:Connect(function()
    if coins >= 50 then -- Price for an egg
        coins = coins - 50
        coinsDisplay.Text = "Coins: " .. coins
        petMultiplier = petMultiplier + 0.5 -- Pets provide strength multipliers
        print("Pet hatched! Strength Multiplier: " .. petMultiplier)
    end
end)

-- Real-time UI Updates
strengthDisplay.Text = "Strength: " .. strength
coinsDisplay.Text = "Coins: " .. coins

-- Pet Inventory (Display Pets)
local petInventory = playerGui:WaitForChild("PetInventory")
local petList = petInventory.InventoryFrame.PetList
petList.Text = "No Pets Hatched"
