
# Sword Simulator - Roblox Game (.rbxl)

## Game Features:
- Players gain strength by swinging swords.
- Strength can be sold for coins.
- Coins can be used to buy better swords.
- Players can hatch pets that provide strength multipliers.
- UI includes HUD (Strength and Coins), Shop UI, and Pet Inventory.

## How to Use:
1. Open Roblox Studio.
2. Click "Open File" and select the Sword_Simulator.rbxl file.
3. Explore the main area, shop, selling zone, and pet hatchery.
4. Customize the game further by editing the world or scripts.

## Important Notes:
- All scripts are optimized and properly linked to UI elements.
- The game is ready for direct publishing to Roblox.
- You can easily add more swords, pets, and unlockable areas for expansion.

## Need Help?
If you have any questions, feel free to ask!
