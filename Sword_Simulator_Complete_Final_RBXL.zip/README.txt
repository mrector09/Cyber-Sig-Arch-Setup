
# Sword Simulator - Complete Project (Roblox)

## Features:
- Complete World Layout (Spawn, Shop, Selling Zone, Pet Hatchery, Advanced Zones).
- Animated Loading Screen with Sword Animation.
- Strength System: Gain strength by swinging swords.
- Currency System: Sell strength for coins.
- Sword System: Buy and equip stronger swords.
- Pet System: Hatch pets with strength multipliers.
- Advanced Zones: Snow World, Lava World, Space World.
- Gamepasses (Monetization):
  - Auto-Swing (Automatically gain strength without clicking).
  - Double Coins (Earn 2x coins from selling).
  - Exclusive Pets (Special pets with high multipliers).

## How to Use:
1. Open the Sword_Simulator_Complete_Final.rbxlx file in Roblox Studio.
2. Customize the world, swords, and pets as needed.
3. Publish directly to Roblox for player access.

## Customization:
- You can add new zones, swords, and pets easily.
- The UI is fully editable (HUD, Shop, Pet Inventory).
- The scripts are clean and optimized for easy modification.

## Need Help?
Feel free to ask for further customization or new features.
