
import tkinter as tk
import ctypes
import sys
import os

# Attach Function (DLL)
def attach_to_roblox():
    dll_path = os.path.join(os.getcwd(), "LexarDLL.dll")
    if os.path.exists(dll_path):
        dll = ctypes.WinDLL(dll_path)
        dll.AttachToRoblox()
        print("Successfully attached to Roblox!")
    else:
        print("DLL file not found!")

# Command Line Option (Attach from Java GUI)
if len(sys.argv) > 1 and sys.argv[1] == "attach":
    attach_to_roblox()
    sys.exit()

# GUI Setup (Script Hub)
root = tk.Tk()
root.title("LexarLua - Python GUI")

script_text = tk.Text(root)
script_text.pack()

execute_button = tk.Button(root, text="Execute Script", command=lambda: print(script_text.get("1.0", "end")))
execute_button.pack()

attach_button = tk.Button(root, text="Attach to Roblox", command=attach_to_roblox)
attach_button.pack()

root.mainloop()
