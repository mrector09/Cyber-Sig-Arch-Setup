
// LexarLua - Advanced JavaFX GUI (Java + DLL)
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.*;

public class LexarLua extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("LexarLua - Advanced Lua Executor");
        BorderPane layout = new BorderPane();

        // Sidebar
        VBox sidebar = new VBox();
        Button attachButton = new Button("Attach to Roblox");
        Button scriptHubButton = new Button("Script Hub");
        Button settingsButton = new Button("Settings");
        sidebar.getChildren().addAll(attachButton, scriptHubButton, settingsButton);
        layout.setLeft(sidebar);

        // Main Panel (Dynamic Content)
        TextArea scriptArea = new TextArea("Enter your script here...");
        Button executeButton = new Button("Execute Script");
        VBox mainPanel = new VBox(scriptArea, executeButton);
        layout.setCenter(mainPanel);

        // Execute Script Button
        executeButton.setOnAction(e -> {
            String script = scriptArea.getText();
            System.out.println("Executing Script: " + script);
        });

        // Attach to Roblox (Using DLL via Python)
        attachButton.setOnAction(e -> {
            try {
                Process process = Runtime.getRuntime().exec("python LexarLua.py attach");
                System.out.println("Attempting to attach to Roblox via DLL");
            } catch (IOException ex) {
                System.out.println("Failed to attach: " + ex.getMessage());
            }
        });

        Scene scene = new Scene(layout, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
