
import os

print("Compiling LexarLua into EXE...")
os.system('pyinstaller --onefile --windowed LexarLua.py')
print("Compilation Complete!")
