
# LexarLua - Complete Project (Java + Python + DLL + EXE)

## Features:
- Sleek Java GUI (JavaFX) for Lua script execution.
- Python GUI with DLL integration for Roblox attachment.
- Functional DLL (LexarDLL.dll) for Roblox attachment.
- Python script for compiling the Python GUI into an EXE.

## How to Use:
1. Compile the Java GUI (LexarLua.java).
2. Use LexarLua.py for the Python GUI (Attach and Script Execution).
3. To create an EXE, run compile_to_exe.py:
   python compile_to_exe.py

## Customization:
- Modify the Java or Python GUI for more features.
- Replace the DLL with a more advanced version for better attachment.
